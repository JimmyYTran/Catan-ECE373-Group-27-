import org.catan.cards.*;
import org.catan.map.*;
import org.catan.players.*;
import Start;

public class Driver {
	
	public static void main(String[] args) {
			Map map = new Map();
			String resourceList[] = {"brick", "lumber", "grain", "wool", "ore"};		
			int number = 3;//input
			String names[] = {"Justin", "Jimmy", "Kyler"};//input
			Start start = new Start;
			
		//	Start.createPlayers(number, names);
			
			for (int i = 0; i < Start.createPlayers(number, names).sizeof();i++) {
				
			}
		
			
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	

}