Group project for ECE 373 at the University of Arizona

Team Members: Justin Sabino Carlson, Kyler Fong Gee, Jimmy Tran