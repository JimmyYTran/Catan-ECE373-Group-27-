//incldue package

import org.catan.cards.*;
import org.catan.map.*;
import org.catan.players.*;

import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class CatanGui extends JFrame
{
	private Map map;
	private JMenuBar menuBar;
	private JMenu options;
	
	//Options submenus
	
	private JMenuItem optionClose;
	private JMenuItem optionRules;
	
	public CatanGui()
	{
		super("Catan");
		
		setSize(500,500);
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		
		
		add(new JLabel("<HTML><center>Welcome to Catan!</center><HTML>" ));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//buildGUI();
		setVisible(true);
	
	}
	
	public void buildGUI()
	{
		menuBar = new JMenuBar();
		
		options = new JMenu("Options");
		optionClose = new JMenuItem("Close");
		optionRules = new JMenuItem("Rules");
		
		//optionClose.addActionListener(new MenuListener ());
		//optionRules.addActionListener(new MenuListener ());
		
		options.add(optionClose);
		options.add(optionRules);
		
		menuBar.add(options);
		
		setJMenuBar(menuBar);
	}
	
	private class MenuListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) {
			JMenuItem source = (JMenuItem)(e.getSource());
			
			//if(source.equals(funciton)){
			//handleFunction();
			//}
		}
		//private void handleFunction() {}
		
	}
	
	
	












}

