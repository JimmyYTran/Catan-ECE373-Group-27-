package org.catan.cards;

public class Monopoly extends Card{
	
	public Monopoly () {
		super.rule = "When you play this card announce 1 type of resource. All other players must give you all of their resources of that type";
	}
}