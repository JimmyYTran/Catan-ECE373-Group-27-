package org.catan.cards;

public class Knight extends Card{
	
	public Knight () {
		super.rule = "Move the robber. Steal 1 resource from the owner of a settlement or city adjacent to the robber's new hex";
	}
}
