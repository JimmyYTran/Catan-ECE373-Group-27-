package org.catan.cards;

public class VictoryPoint extends Card{
	
	public VictoryPoint () {
		super.rule = "Reveal this card on your turn if, with it, you reach the number of points required for victory";
	}
}