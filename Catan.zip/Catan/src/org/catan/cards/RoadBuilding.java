package org.catan.cards;

public class RoadBuilding extends Card{
	
	public RoadBuilding () {
		super.rule = "Place 2 new roads as if you had just built them";
	}
}