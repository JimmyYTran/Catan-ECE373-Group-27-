package development;

public class Victorypoint extends Cards{
	
public Victorypoint () {
	super.rule = "Reveal this card on your turn if, with it, you reach the number of points required for victory";
}




}