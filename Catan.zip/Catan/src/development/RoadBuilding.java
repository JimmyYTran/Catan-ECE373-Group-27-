package development;

public class RoadBuilding extends Cards{
	
public RoadBuilding () {
	super.rule = "Place 2 new roads as if you had just built them";
}




}