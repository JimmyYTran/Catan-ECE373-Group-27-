package development;

public class Cards{
	protected String rule = "";
	
	public Cards() {}
	
	public String getRule() {return this.rule;}
	
	public void setRule(String rule) {
		this.rule = rule;
	}
	
	
}