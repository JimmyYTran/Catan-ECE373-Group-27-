package development;

public class Monopoly extends Cards{
	
public Monopoly () {
	super.rule = "When you play this card announce 1 type of resoure. All other players Must give you all of their resources of that type";
}




}