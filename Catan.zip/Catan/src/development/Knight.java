package development;

public class Knight extends Cards{
	
public Knight () {
	super.rule = "Move the robber. Steal 1 resource from the owner of a settlement or city adjacent to the robber's new hex";
}




}