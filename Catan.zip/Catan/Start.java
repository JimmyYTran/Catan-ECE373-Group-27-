import java.util.ArrayList;

import org.catan.cards.*;
import org.catan.map.*;
import org.catan.players.*;


public class Start {
	private Arraylist<Player> players;
	
	public Start() {
		 players = new ArrayList<Player>();
	}
	
	//When implemented into the GUI this will ask for number of players and then names for players
	//Those will be used for inputs
	public Arraylist<Player> createPlayers (int number, String names[]) {
		for (int i = 0; i < number; i++ ) {
			players.add(new Player());
			players.setName(names[i]);
		}
		return players;
	}
	
	
	
	
	
	
}